"""VLM-goal mission with a classical depth guard (the thesis stack, no SNN).

    RGB  -> VLM box -> 3-D goal (box centre ray x depth)      every ~1-2 s, consensus over a few answers
    depth -> corridor check along the commanded direction     every control step (10-30 Hz)
    goal + guard -> velocity setpoint for PX4 (OFFBOARD)

Everything here is pure (no I/O, no clock): unit-tested, identical in Gazebo and on the drone.

Frames. Camera optical: x right, y down, z forward. Body FRD: x forward, y right, z down (the camera looks
along body x; cam_offset_frd is the camera position in the body frame). World: PX4 local NED.
A pinhole camera is described by its image size and horizontal field of view (square pixels).
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional, Sequence, Tuple

import numpy as np


# ----------------------------------------------------------------------------- geometry
@dataclass
class Pinhole:
    width: int
    height: int
    hfov_rad: float

    @property
    def f(self) -> float:
        return (self.width / 2.0) / math.tan(self.hfov_rad / 2.0)

    def ray(self, u: float, v: float) -> np.ndarray:
        """Unit-depth ray (body FRD, x = 1) through pixel (u, v) (pixel centres at +0.5)."""
        return np.array([1.0, (u - self.width / 2.0) / self.f, (v - self.height / 2.0) / self.f])

    def pixel(self, p_frd: np.ndarray) -> Optional[Tuple[float, float]]:
        if p_frd[0] <= 1e-6:
            return None
        return (p_frd[1] / p_frd[0] * self.f + self.width / 2.0, p_frd[2] / p_frd[0] * self.f + self.height / 2.0)


def R_ned_from_frd(roll_deg: float, pitch_deg: float, yaw_deg: float) -> np.ndarray:
    """Body FRD -> local NED (ZYX Euler, as PX4/MAVSDK report it)."""
    r, p, y = (math.radians(a) for a in (roll_deg, pitch_deg, yaw_deg))
    cr, sr, cp, sp, cy, sy = math.cos(r), math.sin(r), math.cos(p), math.sin(p), math.cos(y), math.sin(y)
    return np.array([[cp * cy, sr * sp * cy - cr * sy, cr * sp * cy + sr * sy],
                     [cp * sy, sr * sp * sy + cr * cy, cr * sp * sy - sr * cy],
                     [-sp, sr * cp, cr * cp]])


def box_depth(depth_m: np.ndarray, depth_cam: Pinhole, rgb_cam: Pinhole, box: Sequence[float],
              shrink: float = 0.5, min_valid: int = 5, dmin: float = 0.2, dmax: float = 20.0) -> Optional[float]:
    """Distance (along the camera axis) of the object in a normalised RGB box [x1, y1, x2, y2] (0..1): the median
    depth of the central part of the box (shrink = fraction of the box kept), mapped into the depth image by ray
    angle (the two cameras share an origin and axis but can differ in size and field of view)."""
    x1, y1, x2, y2 = box
    cx, cy, hw, hh = (x1 + x2) / 2, (y1 + y2) / 2, (x2 - x1) * shrink / 2, (y2 - y1) * shrink / 2
    corners = []
    for ux, vy in ((cx - hw, cy - hh), (cx + hw, cy + hh)):
        q = depth_cam.pixel(rgb_cam.ray(ux * rgb_cam.width, vy * rgb_cam.height))
        corners.append(q)
    (u0, v0), (u1, v1) = corners
    h, w = depth_m.shape[:2]
    a0, a1 = int(max(0, math.floor(min(u0, u1)))), int(min(w, math.ceil(max(u0, u1)) + 1))
    b0, b1 = int(max(0, math.floor(min(v0, v1)))), int(min(h, math.ceil(max(v0, v1)) + 1))
    if a0 >= a1 or b0 >= b1:
        return None
    win = depth_m[b0:b1, a0:a1].astype(np.float64)
    ok = np.isfinite(win) & (win >= dmin) & (win <= dmax)
    if ok.sum() < min_valid:
        return None
    return float(np.median(win[ok]))


def goal_from_box(box: Sequence[float], dist_m: float, rgb_cam: Pinhole, state, cam_offset_frd=(0.12, -0.03, -0.24),
                  standoff_m: float = 1.5, keep_alt: bool = True) -> np.ndarray:
    """NED point to fly to: along the ray through the box centre, `standoff_m` short of the object; at the current
    altitude if keep_alt (the VLM picks WHERE, not how high - as in VLN on the Fly)."""
    cx, cy = (box[0] + box[2]) / 2 * rgb_cam.width, (box[1] + box[3]) / 2 * rgb_cam.height
    ray = rgb_cam.ray(cx, cy)
    p_obj = np.asarray(cam_offset_frd) + ray * dist_m  # body FRD
    R = R_ned_from_frd(state.roll_deg, state.pitch_deg, state.yaw_deg)
    pos = np.array([state.north_m, state.east_m, state.down_m])
    obj = pos + R @ p_obj
    d = obj - pos
    d[2] = 0.0 if keep_alt else d[2]
    n = float(np.linalg.norm(d))
    goal = obj - d / n * min(standoff_m, n) if n > 1e-6 else pos.copy()
    if keep_alt:
        goal[2] = pos[2]
    return goal


# ----------------------------------------------------------------------------- depth guard
@dataclass
class GuardResult:
    dist_ahead_m: float  # closest obstacle in the corridor (inf = none in range)
    ttc_s: float  # dist / speed (inf if not moving towards anything)
    blocked: bool
    reason: str = ""


def corridor_distance(depth_m: np.ndarray, cam: Pinhole, dir_frd: np.ndarray, radius_m: float = 0.6,
                      dmin: float = 0.2, dmax: float = 15.0, step: int = 2, k_robust: int = 8) -> float:
    """Distance to the closest obstacle inside a corridor of radius_m around the direction dir_frd (body FRD, from
    the camera): the k_robust-th closest along-track distance, so single noisy pixels do not count. inf = clear
    (as far as the camera sees: only directions inside its field of view are covered)."""
    n = float(np.linalg.norm(dir_frd))
    if n < 1e-6:
        return math.inf
    dvec = np.asarray(dir_frd, float) / n
    d = depth_m[::step, ::step].astype(np.float64)
    h, w = depth_m.shape[:2]
    vs, us = np.mgrid[0:h:step, 0:w:step]
    ok = np.isfinite(d) & (d >= dmin) & (d <= dmax)
    Z = d[ok]
    P = np.stack([Z, (us[ok] + 0.5 - w / 2) / cam.f * Z, (vs[ok] + 0.5 - h / 2) / cam.f * Z], -1)  # FRD
    s = P @ dvec
    miss = np.linalg.norm(P - s[:, None] * dvec, axis=-1)
    sel = np.sort(s[(s > 0) & (miss < radius_m)])
    return float(sel[k_robust - 1]) if sel.size >= k_robust else math.inf


def guard(depth_m: Optional[np.ndarray], cam: Pinhole, v_frd: np.ndarray, depth_age_s: float,
          radius_m: float = 0.6, stop_dist_m: float = 1.2, ttc_s: float = 2.0, max_age_s: float = 0.5) -> GuardResult:
    """Block the commanded motion if an obstacle in its corridor is closer than stop_dist_m or would be reached in
    less than ttc_s. No (fresh) depth image -> blocked: never fly blind."""
    if depth_m is None or depth_age_s > max_age_s:
        return GuardResult(math.inf, math.inf, True, "no fresh depth")
    sp = float(np.linalg.norm(v_frd))
    if sp < 0.05:
        return GuardResult(math.inf, math.inf, False, "")
    dist = corridor_distance(depth_m, cam, v_frd, radius_m)
    t = dist / sp if math.isfinite(dist) else math.inf
    if dist < stop_dist_m:
        return GuardResult(dist, t, True, f"obstacle {dist:.1f} m ahead")
    if t < ttc_s:
        return GuardResult(dist, t, True, f"contact in {t:.1f} s")
    return GuardResult(dist, t, False, "")


# ----------------------------------------------------------------------------- goal consensus
@dataclass
class Consensus:
    """Accept a VLM goal only when `need` of the last `window` answers agree within `tol_m` (VLN on the Fly uses 3
    consistent answers; a single answer is wrong too often to fly on). 'Not found' answers count as votes too."""
    need: int = 2
    window: int = 3
    tol_m: float = 1.5
    hist: List[Optional[np.ndarray]] = field(default_factory=list)

    def add(self, goal: Optional[np.ndarray]) -> Optional[np.ndarray]:
        self.hist = (self.hist + [None if goal is None else np.asarray(goal, float)])[-self.window:]
        pts = [g for g in self.hist if g is not None]
        best = None
        for g in pts:
            close = [h for h in pts if np.linalg.norm((h - g)[:2]) <= self.tol_m]
            if len(close) >= self.need and (best is None or len(close) > len(best)):
                best = close
        return np.mean(best, axis=0) if best else None


# ----------------------------------------------------------------------------- velocity command
@dataclass
class Command:
    vx: float  # body forward, m/s
    vy: float  # body right
    vz: float  # down
    yaw_rate: float  # deg/s
    phase: str
    note: str = ""


def steer(goal_ned: Optional[np.ndarray], state, vmax: float = 1.0, k_pos: float = 0.6, k_yaw: float = 1.5,
          max_yaw_rate: float = 30.0, arrive_m: float = 0.5, yaw_first_deg: float = 30.0) -> Command:
    """P-control to the goal: turn to face it (the camera, and so the guard, look forward), then fly forward with
    speed proportional to the distance, capped at vmax. Altitude held to the goal's."""
    if goal_ned is None:
        return Command(0, 0, 0, 0, "search", "no goal")
    pos = np.array([state.north_m, state.east_m, state.down_m])
    d = np.asarray(goal_ned) - pos
    dh = math.hypot(d[0], d[1])
    vz = max(-0.5, min(0.5, k_pos * d[2]))
    if dh < arrive_m:
        return Command(0, 0, vz, 0, "arrived")
    bearing = math.degrees(math.atan2(d[1], d[0]))
    err = (bearing - state.yaw_deg + 180) % 360 - 180
    yaw_rate = max(-max_yaw_rate, min(max_yaw_rate, k_yaw * err))
    if abs(err) > yaw_first_deg:
        return Command(0, 0, vz, yaw_rate, "turn")
    v = min(vmax, k_pos * dh) * math.cos(math.radians(err))
    return Command(v, 0, vz, yaw_rate, "fly")


def apply_guard(cmd: Command, g: GuardResult) -> Command:
    if g.blocked and (abs(cmd.vx) > 0 or abs(cmd.vy) > 0):
        return Command(0, 0, cmd.vz, cmd.yaw_rate, "blocked", g.reason)
    return cmd
