#!/usr/bin/env python3
"""Sweep SNN thresholds on the synthetic simulator: detection time-to-contact vs false alarms.

Pick the MOST SENSITIVE setting that still keeps a safety factor (>= 2x) above the false-alarm
cliff, as the shipped defaults do. Synthetic results only: repeat this on real recordings with
scripts/replay_snn.py before trusting any threshold.

    python scripts/sweep_snn.py --theta 2.5 4 6 --rate 10 15 20
"""
import _path  # noqa: F401
import argparse
import itertools

from neurodrone.closedloop import open_loop_trial
from neurodrone.config import SNNConfig
from neurodrone.sim import Box

ap = argparse.ArgumentParser()
ap.add_argument("--theta", type=float, nargs="+", default=[2.5, 4.0, 6.0])
ap.add_argument("--rate", type=float, nargs="+", default=[10.0, 15.0, 20.0])
ap.add_argument("--speed", type=float, default=1.5)
args = ap.parse_args()

DET = {"wall 3m": ([Box(x=14, y=0, w=3, h=3)], {}),
       "box 1.5m": ([Box(x=14, y=0, w=1.5, h=1.5)], {}),
       "blank 3m": ([Box(x=14, y=0, w=3, h=3, texture="blank")], {}),
       "pole 0.4m": ([Box(x=14, y=0, w=0.4, h=3)], {}),
       "pole 0.15m": ([Box(x=14, y=0, w=0.15, h=3)], {})}
FA = {"stationary+jitter, object": ([Box(x=14, y=2, w=2, h=2)], dict(speed=0.0, jitter_deg=3.0, dur=6)),
      "fwd+jitter 5deg empty": ([], dict(jitter_deg=5.0, dur=8)),
      "yaw 30deg/s empty": ([], dict(speed=0.0, yaw_rate_deg_s=30.0, dur=6)),
      "noise 3Hz/px empty": ([], dict(noise_hz=3.0, dur=8))}

print("detection columns: time-to-contact (s) at first alarm, higher = earlier warning; 'miss' = never alarmed")
print(f"{'theta':>5} {'rate':>5} | " + " ".join(f"{k:>10}" for k in DET) + " | worst false-alarm urgency")
for th, ra in itertools.product(args.theta, args.rate):
    cfg = SNNConfig(theta=th, rate_alarm=ra)
    cols = []
    for boxes, kw in DET.values():
        first, _ = open_loop_trial(boxes, cfg, speed=args.speed, **kw)
        cols.append("miss" if first is None else f"{first / args.speed:.1f}")
    worst = max(open_loop_trial(b, cfg, **kw)[1] for b, kw in FA.values())
    flag = "  <-- FALSE ALARM" if worst >= 1.0 else ""
    print(f"{th:5.1f} {ra:5.0f} | " + " ".join(f"{c:>10}" for c in cols) + f" | {worst:.2f}{flag}", flush=True)
