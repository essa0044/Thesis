# Handoff: drone SNN + VLM bachelor-thesis project

> **For the receiving Claude.** You are continuing a long conversation with a bachelor student. Read this whole file, then `neurodrone/README.md`
> (inside the zip). Trust labels used below:
> **[verified-sim]** = checked by automated tests in a *synthetic* simulator only. **[unverified]** = written but never run on hardware, PX4 SITL, or a real VLM.
> **[re-verify]** = from web searches done in the previous conversation (current date there: Oct 2026); check before the student cites it.
> Unlabelled advice is the previous model's judgement. Never present [unverified] or [re-verify] items as established fact.
>
> **About the student:** writes casually (lowercase, typos), uses the Claude mobile app, often just says "continue" to let you proceed.
> Keep replies skimmable and answer-first; be upfront about what is and isn't tested; push back constructively on scope.

## 1. TL;DR

* **Thesis idea:** evaluate the *feasibility of running LLM/VLM-based control onboard a drone* (VLM invoked every ~10 s vs continuously: undecided).
  Their professor told them to read "a paper called neuromorphic". The student then proposed combining a **neuromorphic SNN** (fast reflex) with a **VLM** (slow semantics).
* **Architecture settled on:** three tiers, not two: (1) PX4 autopilot does all stabilisation (hundreds of Hz+); (2) event camera + SNN = always-on reflex;
  (3) VLM = periodic visual grounding (every 1-10 s). A coordinator fuses them. Fully-spiking VLAs (SpikeVLA) are "where the field is heading", not a bachelor's build.
* **Built:** a Python project `neurodrone/` (milestone 1; ~3,700 lines; **85 tests pass**), simulator-verified only.
* **Unanswered question to the student:** *which hardware do they actually have* (event sensor model, PX4/Pixhawk version, VLM runtime, RGB-D camera)? They said "presume I have the hardware".
* **Biggest honesty caveat:** nothing has touched real hardware, PX4 SITL, or a real VLM. All numbers below are synthetic.

## 2. Conversation arc

1. Student's proposal + questions: GPU needs, where to train/simulate, existing models, which models to evaluate, the professor's neuromorphic paper, "would we use an Orin?"
2. Asked for a summary of the **GRaD-Nav++** paper (confused by its Mixture-of-Experts).
3. Asked whether **SNN + VLM** together is a good idea / done before / what the stack looks like; then "is a neuromorphic camera the same as an event camera?" (yes: same sensor, a.k.a. DVS).
4. Asked for a hardware list, SpikeVLA vs hybrid, whether the SNN drives the motors, how the drone stays stable, what happens when the VLM is "blind for 10 s", and how an SNN reacts with only brightness changes.
5. "Now start building it, presume I have the hardware" -> the codebase (many "continue" turns; bugs found and fixed along the way, see section 7).
6. Finally: asked for this handoff.

## 3. Research findings [re-verify before citing]

**Hardware**
* **Jetson Thor** (Blackwell): up to ~2070 FP4 TFLOPS, 128 GB, ~40-130 W, ~7.5x compute / 3.5x efficiency vs AGX Orin; aimed at humanoids/ground robots. Too heavy on power/weight for a small quadcopter.
  **Jetson Orin Nano/NX** (~7-25 W) are the practical flight computers; AGX Orin up to ~60 W. Real onboard-drone papers use Orin Nano/NX/AGX. Advice: Orin Nano/NX, and justify the SWaP trade-off explicitly in the thesis.
* **Dev machine:** no need for a cluster: zero-shot eval of existing small VLMs, optionally LoRA/QLoRA on a 24 GB GPU (3090/4090) or rented GPU. Training a VLM from scratch is out of scope. Isaac Sim needs a decent RTX card.
* **Neuromorphic chips:** Intel Loihi is not commercially available (research access via INRC). SynSense Speck demo kit seen listed at ~$199 (a pre-order listing in search results; availability/host data access **unconfirmed**).
  BrainChip Akida: AKD1500 "BrainBoard" with an open-source toolchain announced Aug 2026.
* **Sim platforms:** Gazebo + PX4 SITL (most mature, plain visuals), AirSim/Cosys-AirSim (Microsoft's original is no longer developed), Isaac Sim + Pegasus (photoreal, steeper). One team's plan estimated 18-22 weeks solo to real-flight VLM navigation with Isaac Sim + PX4 (anecdotal GitHub doc): so a real flying demo is a stretch goal for a bachelor thesis; **bench/sim characterisation is a complete thesis** (latency, power, accuracy trade-offs).
* **Candidate VLMs for Orin-class (2-7B, quantised via TensorRT-LLM or llama.cpp/GGUF):** SmolVLM2 (2.2B), Moondream2 (~2B), PaliGemma2 (3B), Qwen2.5-VL (3B/7B), MiniCPM-V.

**Papers** (arXiv IDs as retrieved in the conversation)
| Work | Why it matters |
|---|---|
| Survey *Vision-Language Navigation for Aerial Robots: Towards the Era of LLMs* (2604.07705) | Best literature-review anchor; Section VI-E "Onboard Deployment and Computational Efficiency" states current VLMs exceed what lightweight UAVs can carry: i.e. the thesis problem statement. |
| **GRaD-Nav++** (2506.14009; Stanford/Schwager lab) | Onboard VLA on **Orin Nano**: frozen CLIP ViT-B/32 (150M) + CENet (0.5M) + **MoE policy (1M, 2 experts)**, ~6 GB; policy ~30 ms/step, ~120 ms when CLIP runs; **CLIP updated every 10 steps at 25 Hz (~0.4 s)** = a concrete periodic-VLM precedent. Trained with differentiable RL in a 3D-Gaussian-Splatting sim (~8 h, one RTX 4090). Real flight 67 % (trained tasks) / 50 % (unseen) vs 83 % / 75 % in sim. MoE's benefit = less catastrophic forgetting across environments (~70 % vs 25-33 % for single/large-net baselines), not raw accuracy; 8 experts dropped the Orin Nano loop to 10 Hz and hurt real flight. Limitation: only recombines seen sub-tasks (not open vocabulary). |
| SINGER (2509.18610), OnFly, LiteVLA-H (dual-rate VLA, AGX Orin), CoDrone (edge/cloud split), AutoFly | Onboard / dual-rate aerial VLA precedents. |
| **Neuro-LIFT** (2501.19259; Purdue) | Closest SNN+language precedent: text-only **Llama-3.2-3B** go/no-go + event camera (DAVIS346B) + SNN planner (EV-Planner) on a Jetson Nano, **Parrot Bebop2**. The LLM never sees images. Payload was so tight the sensors had to sit **off-board** on a tripod with mocap compensation: a scope warning. |
| **SpikeVLA** (2606.27807) | Fully spiking VLA (spiking SigLIPv2 encoder + ANN-to-SNN-converted LLaMA-8B + spiking policy); evaluated with a *theoretical* energy metric, not flown. |
| Hybrid SNN-ANN deployment (2407.08704) | Loihi + Jetson Nano bridged by an "accumulator"; authors could not measure inter-chip communication cost. |
| TU Delft, *Fully neuromorphic vision and control for autonomous drone flight* (Paredes-Vallés et al., Science Robotics 2024; arXiv 2303.08778) | **Best guess** for the professor's "neuromorphic paper" (unconfirmed: ask the student): SNN on Loihi, event camera, ~200 Hz, ~<1 W. A 2025 Nature Comms Eng. perspective on neuromorphic robotic vision is the alternative reading. |

**Gap the thesis can claim:** a *real, image-ingesting conventional VLM* paired with a *neuromorphic reflex* as peers: Neuro-LIFT avoided a true VLM; SpikeVLA is not hybrid. (Stated as "appears to be a gap" from the searches done; not an exhaustive survey.)

## 4. Concepts already explained to the student (stay consistent)

* **Stability** is solved by PX4's own control loop on the Pixhawk (IMU, PID); not an AI problem. Our software only streams body-frame velocity setpoints in OFFBOARD mode.
* **The SNN does not drive motors** (except one narrow TU Delft landing demo). It outputs alarms/urgency; the coordinator turns them into setpoints.
* **"Blind for 10 s" is a misconception:** the event camera + SNN run continuously; "periodic" only describes how often the VLM refreshes its semantic goal. Same pattern as GRaD-Nav++ (depth-based avoidance every step; CLIP every 10).
* **How a brightness-change sensor sees obstacles:** relative motion makes every edge emit events; an approaching object makes an *expanding* pattern (looming), a time-to-contact cue like fly LGMD vision. Needs contrast/texture: blank surfaces, glass, thin wires defeat it.
* **Decision-level fusion** (VLM decides what, SNN/PX4 execute) is the right level for a bachelor's; feature-level SNN->VLM fusion is research-grade.
* "Every 10 s" is a mission-level re-planning cadence, not an obstacle-reaction cadence.

## 5. The codebase (`neurodrone/`)

```
Event camera -> LoomingSNN (NumPy, hand-designed, ~100 Hz) -> ThreatReport -+
Depth camera -> corridor_range (range reflex, fail-closed) -> ClearanceReport +-> Coordinator.step() -> VelocityCmd -> Vehicle (PX4/MAVSDK)
RGB camera  -> VLM server (OpenAI-compatible HTTP, every vlm.period_s) -> SemanticGoal -+
```
| Module | Role |
|---|---|
| `types.py`, `config.py` | dataclasses; every tunable in one place (+ `config/default.yaml`, kept in sync by a test) |
| `snn.py` | `LoomingSNN.process(EventPacket)->ThreatReport`: time-surface EMDs (delay-and-coincidence), divisive z-score, LIF neurons; alarm = **mirrored left/right coincidence neurons per radial band** |
| `coordinator.py` | pure, clock-injected state machine; modes IDLE, BLIND_HOLD, NO_GOAL, TRACK, SEARCH, ADJUDICATE, AVOID, SETTLE, ARRIVED, FAILSAFE |
| `vlm.py` | prompt (target -> normalised box JSON), tolerant `parse_goal`, `encode_jpeg`, `OpenAICompatVLM`, `MockVLM` |
| `runtime.py` | `Brain` (sync core shared by sim and real flight) and `Pipeline` (SNN thread + VLM thread + range thread + asyncio control loop) |
| `vehicle.py` | `SimVehicle`; `Px4Vehicle` via **`mavsdk_grpc`** [unverified on SITL/hardware] |
| `events.py`, `camera.py`, `depth.py` | `ReplayEventSource` (npz); `DavisLiveSource`, `OpenCVCamera`, `RealSenseClearance` [all unverified: no hardware] |
| `telemetry.py` | JSONL logger, `PowerSampler` (jtop/tegrastats regexes from memory [unverified]), `summarize_log` |
| `sim.py`, `closedloop.py` | synthetic DVS, textured-billboard world, point-mass drone, scenarios, `PacketCutter`, `open_loop_trial` |
| `safety.py` | `stopping_distance`, `max_safe_speed`, `max_safe_speed_ttc` |

Scripts: `run_px4.py` (flight/dry-run; defaults to pilot-engaged OFFBOARD; **refuses to fly without the range sensor** unless `--allow-no-range`), `bench_vlm.py`,
`replay_snn.py`, `sim_closed_loop.py`, `trace_scenario.py`, `sweep_vlm_latency.py`, `sweep_snn.py`, `make_demo_events.py`.

**Behaviour in one paragraph:** the coordinator follows the VLM's target bearing (corrected for yaw that happened during VLM latency) while the SNN/range reflex watch. On any alarm it **brakes and waits for a VLM
image captured *after* the alarm**: target (centred, box >= 20 % of image width) -> ARRIVED/hold; otherwise a timed, open-loop sidestep (escalating, same direction) -> settle -> wait for a post-sidestep goal; >4 dodges in 25 s -> hold ("stuck").
Alarm persisting while stopped -> dodge now. SNN (or enabled range sensor) stale -> hold still; after 3 s -> land. Battery/geofence -> land/hold. A parse failure/timeout keeps the old goal until it expires (8 s).

**Key defaults:** SNN theta=4, rate_alarm=15 (needs >=2 spikes within ~70 ms), tau_m 50 ms, tau_rate 100 ms, dt window 2-150 ms, bands (0,.14,.28,.5) x width. Coordinator cruise 1.0 m/s, max 1.5, brake_decel 2.0 (assumed), reaction 0.4 s (assumed),
dodge 1 m/s x 2 m, range margin 0.8 m, `use_clearance=False` in config (the flight script forces it on with `--depth`). VLM period 2 s, image max side 448 (multiples of 28).

**Verified environments:** 85/85 tests on Python 3.12 + NumPy 2.4/2.5 and Python 3.10 + NumPy 1.21.5/2.2.6 (x86-64). Not tried on ARM/Jetson or Python 3.9. Install: `pip install -e '.[dev]'`.
**MAVSDK gotcha:** `pip install mavsdk` (>=4) is a different native API and will break the adapter; use `pip install mavsdk-grpc` (import `mavsdk_grpc`) or `mavsdk<4`. API names were checked against mavsdk-grpc 3.17.4.

## 6. Results [verified-sim only: not performance predictions]

* **Alarm range** at 1.5 m/s, realistic packetisation, 8 seeds (min-median-max): 3 m textured wall 6.6-6.8-7.3 m; 2 m box 5.9-6.1-6.6; 1.5 m box 4.9-5.3-5.3; blank 3 m wall dead ahead 7.9-8.4-8.9 (via its edges); 0.4 m pole 3.8-3.9-4.0; **0.15 m pole missed**.
  Alarm time-to-contact falls with speed (3 m wall: 6.3 s at 0.8 m/s -> 2.7 s at 5 m/s). Stopping from 1.5 m/s (a=2, 0.4 s reaction) ~1.2 m.
* **False alarms:** none under attitude jitter up to 5 deg at 1-3 Hz (peak ~57 deg/s), 30 deg/s yaw, 3 Hz/pixel noise, 3x40 s soaks. False-alarm cliff near theta ~1.5 (urgency already 0.67); shipped theta=4 keeps a 2-2.7x margin.
* **SNN cost:** ~0.9 ms per 10 ms packet at 1 Mev/s, ~2.4 ms at 3 Mev/s (346x260, single x86 core); 1.1-2.2 ms across NumPy 1.21-1.26. Jetson ARM cores: unmeasured.
* **VLM latency sweep** (oracle VLM, timing only): open approach mission time 10.5 s (0.5 s latency) -> 14 s (2 s) -> 20 s (4 s) -> 32 s (8 s); time spent braking/waiting 14 % -> 71 %. With an obstacle: 28.5 / 40 / 78 s at 0.5 / 2 / 6 s. **No collisions at any latency: latency costs progress, not safety.**
* Closed-loop scenarios: approach, offset target, jitter, dodge obstacle, VLM silent (never moves), SNN blackout (stops <1.6 m, requests land), blank wall with range sensor (no collision, ends "stuck: hold").

## 7. Design history and known limitations: do NOT silently undo these

**Things the tests caught in the first design (each has a regression test):**
1. A signed sum over the centre sector hit 0.94 of the alarm threshold under mere attitude jitter -> replaced by mirrored-pair coincidence neurons per radial band (translation gives mirror pixels opposite sign; a static obstacle must straddle the direction of motion). The min must be taken *before* integration.
2. Aligned packet boundaries flattered detection (3 m wall alarmed ~1.2 m earlier than for any other alignment) -> `PacketCutter` cuts off-grid with jittered lengths; thresholds re-derived under it.
3. Slowing down on SNN urgency starved its own alarm (looming flow is proportional to speed): alarm at 1.3 m instead of 5 m -> `urgency_slowdown` is off.
4. Advisory side-push drifted the drone off the target line (target looks like an obstacle up close) -> `lateral_gain=0`.
5. Pre-dodge VLM bearings point the wrong way after a sidestep -> goals captured before the sidestep are invalidated.
6. Dodging its own target on a 3 s-stale VLM box -> brake-then-adjudicate on a fresh image.
7. Range speed-cap sat exactly on the range-alarm boundary -> 25 % buffer. Arrival-latch phase bug; search-rotation accounting used the unclamped rate.

**Limitations (also in README):** blank/glass surfaces and thin obstacles defeat the event-camera reflex (**a textureless wall taller than the FOV, approached off-centre, produced zero alarms and the simulated drone crashed; asserted by a test** -> hence the mandatory-once-enabled range reflex);
depth cameras fail on glass/black/sunlight/long range (`invalid_policy="blocked"` fails closed, "free" accepts risk outdoors); reactive avoidance has no memory (turns back toward a target hidden behind the obstacle, needs escalating dodges; wide obstacles -> "stuck");
left/right urgencies are corrupted by rotation (no gyro derotation); "arrived" is a heuristic that ends ~5-7 m from the target; small VLMs localise poorly (use `bench_vlm.py` with labels); synthetic thresholds need re-tuning on real recordings (`replay_snn.py`).

## 8. Open items and next steps

**Ask the student first:** exact event sensor (DAVIS346? Speck kit/DevKit? Prophesee?), Pixhawk + PX4 version, RGB-D camera model, VLM runtime (llama.cpp / Ollama / vLLM), what compute the lab already has (a spare Orin?), thesis timeline, what the professor actually expects.
**Engineering:** PX4 SITL run; Gazebo camera + event bridge (v2e can turn rendered video into events); standoff approach under the range sensor; small obstacle memory for dodges; gyro derotation; on-chip Speck SNN via sinabs/samna (needs training data and a confirmed API);
verify power sampler on a real Jetson; measure SNN timing on the Orin.
**Thesis experiments (each = one script + a log):** (1) `bench_vlm.py` grid: model x quantisation x image size -> latency, tokens, parse rate, localisation error, J/query; (2) latency sweep with *measured* latencies; (3) SNN false alarms/alarm TTC on real recordings; (4) power: SNN vs VLM vs idle on the same board; (5) SITL ablation: SNN-only vs range-only vs both vs neither against textured/blank/thin obstacles.

## 9. Corrections to earlier statements

* I recommended **SynSense Speck (~$199)** as the "standout" event-camera + SNN pick. That is **shaky**: the $199 came from a pre-order listing; Speck runs its *own* on-chip convolutional SNN and returns classification spikes, and I could not confirm the demo kit exposes raw events to a host. The repo's SNN is software on the Orin and does not use Speck.
* The first-round detection numbers (before `PacketCutter`) were optimistic; use section 6.
* "TU Delft paper = the professor's paper" is a guess.

## 10. Provenance

Written by the previous Claude model from its own conversation, in a sandbox with no GPU/hardware and network limited to PyPI/GitHub. Tool outputs from earlier turns are not included; paper details were read from web fetches at the time and may contain errors.
The zip contains the final tested code. Nothing else from the conversation is lost that matters for continuing.

## 11. Suggested first message to the new model

> I'm continuing a project from another Claude conversation. Please read HANDOFF.md fully, then neurodrone/README.md. Don't assume anything is hardware-tested unless it says so. First, tell me in a few lines what you understood, what the biggest risks are, and what you need from me before the next step.
